<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Firebase\JWT\JWT;
use GuzzleHttp\Client;



require '../vendor/autoload.php';
require '../src/config/db.php';

//Dotenv is not working
$dotenv = Dotenv\Dotenv::createImmutable(dirname(__DIR__, 1));
$dotenv->load();
$app_secret = getenv('SECRET');
//print_r($app_secret);

$conf = [
    'settings' => [
        'displayErrorDetails' => true,
    ],
];

$c = new \Slim\Container($conf);
$app = new \Slim\App($c);

require '../src/middleware.php';
require '../src/DI.php';
$container["jwt"] = function ($container) {
    return new StdClass;
};


$app->add(function ($req, $res, $next) {
    $response = $next($req, $res);
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', '*');
});

// Display the login page
$app->get('/', function (Request $request, Response $response, $args) {
    session_start();
    $errorParam = $request->getParam('error');
    if (isset($errorParam)) {
        $flash = $this->get('flash');
        $flash->addMessage('error', 'Please login first.');
    }
    $flash = $this->get('flash');
    $messages = $flash->getMessages();
    if (isset($messages['error'])) {
        foreach ($messages['error'] as $error) {
            echo '<div class="alert alert-danger">' . $error . '</div>';
        }
    }
    $response->getBody()->write(file_get_contents(__DIR__ . '/../templates/login.php'));
    return $response;
});

// Authenticate login
$app->post('/authenticate', function (Request $request, Response $response) {
    session_start();

    $dotenv_file = dirname(__DIR__, 1) . '..\.env';
    $dotenv_contents = file_get_contents($dotenv_file);
    $dotenv_vars = parse_ini_string($dotenv_contents);

    //$name = $request->getParam('name');
    $params = $request->getParsedBody();
    $name = $params['username'] ?? '';
    $pass = $params['password'] ?? '';
    //echo $name;die;
    $sql = "SELECT * FROM customers WHERE DEXT_USERLOGIN = :user_id";
    try {
        // Get DB Object
        $db = new db();
        // Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);
        $stmt->bindParam(':user_id', $name, PDO::PARAM_STR);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $data["success"] = false;
        $data["token"] = null;
        $status = 404;
        foreach ($users as $user) {
            //user does exist
            if ($user['DEXT_USERLOGIN'] === $name && $user['DEXT_PASSWORD'] === $pass) {
                $roleCheck = substr($name, 0, 1);
                $userRole = 'customer';
                $roleCheck == 'V' ? $userRole == 'vendor' : $userRole == 'customer';
                $MyJWT = $this->JWT;
                $now = new DateTime();
                $future = new DateTime("now +30 days");
                $server = $request->getParams();
                $payload = [
                    "iat" => $now->getTimeStamp(),
                    "exp" => $future->getTimeStamp(),
                    "sub" => $server,
                    "role" => $userRole
                ];
                $secret = $dotenv_vars['SECRET'];

                $token = $MyJWT->encode($payload, $secret, "HS512");

                $sqlTokenCheck = "SELECT * FROM usr_token WHERE user_id = :user_id";
                $token_stmt = $db->prepare($sqlTokenCheck);
                $token_stmt->bindParam(':user_id', $name, PDO::PARAM_STR);
                $token_stmt->execute();
                $userToken = $token_stmt->fetchAll(PDO::FETCH_ASSOC);

                if (empty($userToken)) {
                    $sqlTokenInsertQuery = "INSERT INTO usr_token (user_id, token, created_at)
                    VALUES (:user_id, :token, NOW())";
                    $stmt = $db->prepare($sqlTokenInsertQuery);
                    $stmt->bindParam(':user_id', $name, PDO::PARAM_STR);
                    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
                    $stmt->execute();

                    // Check if the query was successful
                    if ($stmt->rowCount() > 0) {
                        $data["success"] = true;
                        $data["token"] = $token;
                        $data["user"] = $user;
                    } else {
                        $data["success"] = false;
                        $data["token"] = null;
                        $data["user"] = $user;
                    }
                } else { //if token exist
                    $sql = "DELETE FROM usr_token WHERE user_id = :user_id";
                    $stmt = $db->prepare($sql);
                    $stmt->bindParam(':user_id', $name, PDO::PARAM_STR);
                    $stmt->execute();
                    if ($stmt->rowCount() > 0) {
                        $sqlTokenInsertQuery = "INSERT INTO usr_token (user_id, token, created_at)
                    VALUES (:user_id, :token, NOW())";
                        $stmt = $db->prepare($sqlTokenInsertQuery);
                        $stmt->bindParam(':user_id', $name, PDO::PARAM_STR);
                        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
                        $stmt->execute();
                        if ($stmt->rowCount() > 0) {
                            $data["success"] = true;
                            $data["token"] = $token;
                            $data["user"] = $user;
                        } else {
                            $data["success"] = false;
                            $data["token"] = null;
                            $data["user"] = $user;
                        }
                    } else {
                        $data["success"] = false;
                        $data["token"] = null;
                        $data["user"] = $user;
                    }
                }

                // set the token in a cookie
                $cookie_lifetime = 60 * 20; // 20 minutes
                $cookie_params = session_get_cookie_params();
                setcookie('jwt_token', $token, time() + $cookie_lifetime, $cookie_params['path'], $cookie_params['domain'], $cookie_params['secure'], $cookie_params['httponly']);
                $status = 200;
                //->withStatus(302)->withHeader('Location', 'https://kedi-app.com2go.co');
                //return $response->withStatus(302)->withHeader('Location', 'http://localhost:3000/');
                //return $response->withStatus(302)->withHeader('Location', 'https://kedi-app.com2go.co');
            }
        }
        return $response->withStatus($status)->withHeader("Content-Type", "application/json")
            ->write(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT))
            ->withHeader('Access-Control-Allow-Origin', 'https://kedi-app.com2go.co');
    } catch (PDOException $e) {
        echo '{"error": {"text": ' . $e->getMessage() . '}';
    }
});

$app->post('/validate-token', function ($request, $response, $args) {
    
    $dotenv_file = dirname(__DIR__, 1) . '..\.env';
    $dotenv_contents = file_get_contents($dotenv_file);
    $dotenv_vars = parse_ini_string($dotenv_contents);

    $token = $request->getHeader('Authorization')[0];
    //$token = json_decode($request->getBody())->token;
    $token_parts = explode(' ', $token);

    if ($token_parts[0] === 'Bearer') {
        $token = $token_parts[1];
    }

    if (!$token) {
        //return $response->withStatus(202)->withJson(['error' => 'Unauthorized']);
        return $response->withStatus(200)->withJson(['isTokenValid' => false]);
    }
    try {
        $decoded = JWT::decode($token, $dotenv_vars['SECRET'], array('HS512'));
        $data_string = serialize($decoded);
        //file_put_contents($file, $data_string, FILE_APPEND);
        
        //return $response->withStatus(200)->withJson(['message' => 'Token is valid']);
        return $response->withStatus(200)->withJson(['isTokenValid' => true]);
    } catch (\Throwable $th) {

        return $response->withStatus(401)->withJson(['error' => 'Unauthorized']);
    }
});


//http://localhost:8000/?page=0
$app->get('/parts/', function (Request $request, Response $response, array $args) {
    $partsObject = [];
    $page = $request->getQueryParams('page')['page'];
    $size = $request->getQueryParams('size')['size'];
    $sorting = $request->getQueryParams('sorting')['sorting'];
    $columnFilter = $request->getQueryParams('filters')['filters'];
    $customColumnFilter = $request->getQueryParams('customFilters')['customFilters'];
    $isVendor = '';
    $discountedFilter = '';
    $quotaFilter = '';

    if (isset($request->getQueryParams('isVendor')['isVendor']))
        $isVendor = $request->getQueryParams('isVendor')['isVendor'];

    if (isset($request->getQueryParams('discountFilter')['discountFilter']))
        $discountedFilter = $request->getQueryParams('discountFilter')['discountFilter'];

    if (isset($request->getQueryParams('quotaFilter')['quotaFilter']))
        $quotaFilter = $request->getQueryParams('quotaFilter')['quotaFilter'];

    $globalFilter = $request->getQueryParams('globalFilter')['globalFilter'];
    $page *= 100;
    $dotenv_file = dirname(__DIR__, 1) . '..\.env';
    $dotenv_contents = file_get_contents($dotenv_file);
    $dotenv_vars = parse_ini_string($dotenv_contents);

    $sortingQuery = '';
    $filterQuery = '';
    $customFilterQuery = '';
    $quotaFilterQuery = '';
    $isVendorQuery = '';
    $globalFilterDiscount = '';
    $and = '';
    $where = '';
    $where2 = '';
    $vendorSubQuery = '';


    if (!empty(json_decode($sorting))) {
        $soringArray = json_decode($sorting);
        $columnId = $soringArray[0]->id;
        $sortDirection = $soringArray[0]->desc;
        $sortDirection = !empty($sortDirection) ? 'DESC' : 'ASC';
        $sortingQuery = "ORDER BY $columnId $sortDirection";
        // print_r($columnId);
        // print_r($sortDirection ) ; die;
    }

    if (!empty(json_decode($columnFilter)) && !empty($columnFilter)) {
        $columnFilterArray = json_decode($columnFilter);
        $columnId = $columnFilterArray[0]->id;
        $filterValue = $columnFilterArray[0]->value;
        $where = ' WHERE ';
        $filterQuery = "$columnId LIKE :filterValue";
        $and = ' AND ';
        // print_r($columnId);die;
    }
    if (!empty(json_decode($customColumnFilter)) && !empty($customColumnFilter)) {
        $customColumnFilterArray = json_decode($customColumnFilter);
        $columnId = $customColumnFilterArray[0]->id;
        $custonFilterValue = $customColumnFilterArray[0]->value;
        // var_dump($custonFilterValue);die;
        $and = ' AND ';
        $where = ' WHERE ';
        if ($columnId == 'vendors.SUPDES') {
            $vendorSubQuery = ' INNER JOIN vendors on vendors.SUPNAME = parts.DEXT_IMPORTERNAME WHERE vendors.SUPDES LIKE :customFilterValue';
            $where = ' ';
        } else
            $customFilterQuery = " $columnId LIKE :customFilterValue";
    }

    if (!empty(json_decode($isVendor)) && !empty($isVendor)) {
        $isVendorArray = json_decode($isVendor);
        $isVendorValue = $isVendorArray[0]->value;
        // print_r($isVendorValue) ; die;
        $where = ' WHERE ';
        $isVendorQuery = "parts.SUPNAME LIKE :isVendor";
    }

    $and2 = '';
    $and3 = '';
    // if ($customFilterQuery !== '') $and2 = ' AND ';
    // else $and = '';
    // if ($filterQuery == '') $and = '';

    if ($filterQuery == '' && $customFilterQuery == '') {
        $and = '';
        $and2 = '';
    }
    if ($filterQuery == '' && $customFilterQuery !== '') {
        $and = '';
        $and2 = ' AND ';
        if ($isVendorQuery == '') $and2 = '';
    }
    if ($filterQuery !== '' && $customFilterQuery == '') {
        if ($isVendorQuery !== '') {
            $and = ' AND ';
            $and2 = '';
        } else {
            $and = '';
        }
    }
    if ($filterQuery !== '' && $customFilterQuery !== '') {
        if ($isVendorQuery !== '') {
            $and = ' AND ';
            $and2 = ' AND ';
        } else $and2 = '';
    }
    if ($filterQuery !== '' && $vendorSubQuery !== '') {
        $where = ' AND ';
    }

    if (!empty(json_decode($quotaFilter)) && !empty($quotaFilter)) {
        if ($isVendorQuery == '' && $customFilterQuery == '' && $filterQuery == '') {
            $where2 = ' WHERE ';
            $and3 = '';
        } else {
            $where2 = '';
            $and3 = ' AND ';
        }
        if ($vendorSubQuery !== '' && $filterQuery == '')
            $where2 = ' AND ';
        $quotaFilterQuery = ' DEXT_LOWSTOCKQTY > 0 ';
    }
    if ($isVendorQuery !== '' && $quotaFilterQuery !== '') {
        if ($vendorSubQuery !== '')
            $where = ' AND ';
        else $where = ' WHERE ';
        $where2 = '';
    }
    if ($isVendorQuery !== '' && $quotaFilterQuery == '' && $vendorSubQuery !== '')
        $where = ' AND ';

    // $and = '' ? $filterQuery == '' :
    $sql = "SELECT * FROM parts $vendorSubQuery $where $filterQuery $and $customFilterQuery $and2 $isVendorQuery $where2 $and3 $quotaFilterQuery $sortingQuery LIMIT :size OFFSET :page";
    $totalRowsQuery = "SELECT COUNT(PARTNAME) FROM parts $vendorSubQuery $where $filterQuery $and $customFilterQuery $and2 $isVendorQuery $where2 $and3 $quotaFilterQuery";

    // echo $sql;
    // die;

    if (!empty(json_decode($discountedFilter)) && !empty($discountedFilter)) {
        $and2 = '';
        if ($customFilterQuery !== '') $and2 = ' AND ';

        $sql = "SELECT * FROM parts INNER JOIN discount ON parts.PARTNAME = discount.DEXT_OFFERPARTNAME $vendorSubQuery $where $filterQuery $and $customFilterQuery $and2 $isVendorQuery $where2 $and3 $quotaFilterQuery $sortingQuery LIMIT :size OFFSET :page";

        $globalFilterDiscount = " INNER JOIN discount ON parts.PARTNAME = discount.DEXT_OFFERPARTNAME ";

        $totalRowsQuery = "SELECT COUNT(PARTNAME) FROM parts INNER JOIN discount ON parts.PARTNAME = discount.DEXT_OFFERPARTNAME $vendorSubQuery $where $filterQuery $and $customFilterQuery $and2 $isVendorQuery $where2 $and3 $quotaFilterQuery";
        // var_dump($vendorSubQuery);die;
    }

    //global search
    if ($globalFilter !== '' && $globalFilter !== null) {
        if ($isVendorQuery !== '') $and = ' AND ';
        else $and = '';
        if ($filterQuery !== '') $and2 = ' AND ';
        else $and2 = '';
        $and3 = '';
        if ($quotaFilterQuery !== '') $and3 = ' AND ';

        $sql = "SELECT * FROM parts $globalFilterDiscount WHERE PARTNAME OR PARTDES LIKE :globalFilter $and $isVendorQuery $and2 $filterQuery $and3 $quotaFilterQuery $sortingQuery";

        $totalRowsQuery = "SELECT COUNT(PARTNAME) FROM parts $globalFilterDiscount WHERE PARTNAME OR PARTDES LIKE :globalFilter $and $isVendorQuery $and2 $filterQuery $and3 $quotaFilterQuery";
        // var_dump($isVendorQuery);die;
    }

    try {
        // var_dump($sql);die;
        // Get DB Object
        $db = new db();
        // Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);
        $countStmt = $db->prepare($totalRowsQuery);
        //sorting enabled 
        // if (!empty(json_decode($sorting))){
        //     $stmt->bindValue(':columnId', $columnId, PDO::PARAM_STR);
        //     $stmt->bindValue(':sortDirection', $sortDirection, PDO::PARAM_STR);
        // }

        //column search
        if (!empty(json_decode($columnFilter)) && !empty($columnFilter)) {
            $stmt->bindValue(':filterValue', '%' . $filterValue . '%', PDO::PARAM_STR);
            $countStmt->bindValue(':filterValue', '%' . $filterValue . '%', PDO::PARAM_STR);
        }
        if (!empty(json_decode($customColumnFilter)) && !empty($customColumnFilter)) {
            $stmt->bindValue(':customFilterValue', '%' . $custonFilterValue . '%', PDO::PARAM_STR);
            $countStmt->bindValue(':customFilterValue', '%' . $custonFilterValue . '%', PDO::PARAM_STR);
        }
        if (!empty(json_decode($isVendor)) && !empty($isVendor)) {
            $stmt->bindValue(':isVendor', '%' . $isVendorValue . '%', PDO::PARAM_STR);
            $countStmt->bindValue(':isVendor', '%' . $isVendorValue . '%', PDO::PARAM_STR);
        }
        // if (!empty(json_decode($discountedFilter))) {
        //     $stmt->bindValue(':discountedFilterValue', '%' . $discountedFilterValue . '%', PDO::PARAM_BOOL);
        // }

        //user search
        if ($globalFilter !== '' && $globalFilter !== null) {
            $stmt->bindValue(':globalFilter', '%' . $globalFilter . '%', PDO::PARAM_STR);
            $countStmt->bindValue(':globalFilter', '%' . $globalFilter . '%', PDO::PARAM_STR);
            if (isset($filterValue)) {
                $stmt->bindValue(':filterValue', '%' . $filterValue . '%', PDO::PARAM_STR);
                $countStmt->bindValue(':filterValue', '%' . $filterValue . '%', PDO::PARAM_STR);
            }
        } else {
            $stmt->bindValue(':size', $size, PDO::PARAM_INT);
            $stmt->bindValue(':page', $page, PDO::PARAM_INT);
            // print_r($size);die;
        }
        // print_r($globalFilter);die;
        // $stmt->debugDumpParams();
        // die;
        // $stmt->execute();
        $stmt->execute();
        $parts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // print_r($stmt);die;
        // var_dump($parts);die;

        //$toalRows= $stmt->fetch(PDO::FETCH_ASSOC);

        // $toalRows = current($db->query($toalRows)->fetch());
        $countStmt->execute();
        $totalRows = current($countStmt->fetch());
        // print_r($totalRows);die;
        $partsObject = ["totalRows" => $totalRows, "data" => $parts];
        return $response->withStatus(200)->withJson($partsObject);
    } catch (PDOException $e) {
        echo '{"error": {"text": ' . $e->getMessage() . '}';
    }

    return $response;
});

$app->post('/order', function (Request $request, Response $response) { {
        //https://ked.priority-software.com.cy/odata/Priority/tabula.ini/efk/B2B_ORDERS
        $order = $request->getParsedBody();
        // print_r($order);die;
        $username = 'apiuser';
        $password = '1234';

        $client = new Client([
            'base_uri' => 'https://ked.priority-software.com.cy/',
            //'base_uri' => 'https://webhook.site/    ',
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode("$username:$password"),
            ],
            'verify' => false
        ]);
        $response = $client->post('/odata/Priority/tabula.ini/efk/B2B_ORDERS', [
            //$response = $client->post('/8f26953c-abf6-4290-8515-65a906f7df75', [
            'json' => $order,
        ]);

        $body = (string) $response->getBody();
        $data = json_decode($body, true);
        return $body;
        // try {
        //     return $response->withStatus(200)->withJson($data);
        // } catch (\Throwable $th) {
        //     return $response->withStatus(200)->withJson($th);
        // }
    }
});

$app->get('/vendors', function (Request $request, Response $response, array $args) {

    $username = 'apiuser';
    $password = '1234';

    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);

    $response = $client->get('/odata/Priority/tabula.ini/efk/B2B_SUPPLIERS?$filter=STATDES eq \'Active\'', []);

    $body = (string) $response->getBody();
    $data = json_decode($body, true);

    return $response;
});


$app->get('/invoices', function (Request $request, Response $response, array $args) {
    $date = date('Y-m-d', strtotime(date("Y-m-d", strtotime("-30 day"))));

    $username = 'apiuser';
    $password = '1234';

    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);

    $response = $client->get('/odata/Priority/tabula.ini/efk/AINVOICES?$filter=CUSTNAME eq \'C1001\' and STATDES eq \'Final\' and IVDATE ge ' . $date, []);

    $body = (string) $response->getBody();
    // return $data;

    return $response;
});

$app->get('/invoice-pdf', function (Request $request, Response $response, array $args) {
    $invoiceId = $request->getQueryParams('invoice_id')['invoice_id'];
    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'json' => ['IVNUM' => $invoiceId],
        'verify' => false
    ]);


    $response = $client->post('odata/Priority/tabula.ini/efk/DEXT_APINVOS');

    $body = (string) $response->getBody();

    return $body;
});


$app->get('/statements', function (Request $request, Response $response, array $args) {

    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);
    //2022-05-17    
    $todayDate = date("Y-m-d");
    $lastYearDate = date("Y-m-d", strtotime("-1 year"));
    $sub_url = '/odata/Priority/tabula.ini/efk/DEXT_CUSTSTMT?$filter=FROMDATE ge ' . $lastYearDate . ' and TODATE le ' . $todayDate . ' and CUSTNAME eq \'C1001\'';
    // print_r($sub_url);die;
    $response = $client->get($sub_url);

    return $response;
});

$app->get('/backorders', function (Request $request, Response $response, array $args) {
    $date = date('Y-m-d', strtotime(date("Y-m-d", strtotime("-5 day"))));

    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);

    $sub_url = '/odata/Priority/tabula.ini/efk/B2B_BACKORDERS?$filter=CUSTNAME eq \'C1001\' and DEXT_SUBMISSIONDATE ge ' . $date;
    // print_r($sub_url);die;
    $response = $client->get($sub_url);

    return $response;
});

$app->get('/backorder-products', function (Request $request, Response $response, array $args) {
    $order_id = $request->getQueryParams('order_id')['order_id'];
    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);
    $sub_url = '/odata/Priority/tabula.ini/efk/B2B_ORDERS(ORDNAME=\'' . $order_id . '\')?$expand=B2B_ORDERITEMS_SUBFORM';
    // print_r($sub_url);die;
    $response = $client->get($sub_url);

    return $response;
});

$app->get('/return-policy', function (Request $request, Response $response, array $args) {
    $order_id = $request->getQueryParams('barcode')['barcode'];
    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);
    $sub_url = 'odata/Priority/tabula.ini/efk/B2B_LOGPART?$filter=BARCODE eq \'' . $order_id . '\'';
    // print_r($sub_url);die;
    $response = $client->get($sub_url);

    return $response;
});

$app->get('/fetch-orders', function (Request $request, Response $response, array $args) {
    $date = date('Y-m-d', strtotime(date("Y-m-d", strtotime("-5 day"))));
    $customer_id = $request->getQueryParams('customer_id')['customer_id'];
    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);
    $sub_url = 'odata/Priority/tabula.ini/efk/B2B_ORDERS?$filter=CUSTNAME eq \'' . $customer_id . '\' and DEXT_SUBMISSIONDATE ge ' . $date;
    // print_r($sub_url);die;
    $response = $client->get($sub_url);

    return $response;
});

$app->get('/discount', function (Request $request, Response $response, array $args) {

    $sql = "SELECT * FROM discount";

    try {
        // Get DB Object
        $db = new db();
        // Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);
        $stmt->execute();
        $discounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $response->withStatus(200)->withJson($discounts);
    } catch (PDOException $e) {
        echo '{"error": {"text": ' . $e->getMessage() . '}';
    }
});

$app->get('/pharmacies', function (Request $request, Response $response, array $args) {

    $username = 'apiuser';
    $password = '1234';
    $client = new Client([
        'base_uri' => 'https://ked.priority-software.com.cy/',
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode("$username:$password"),
        ],
        'verify' => false
    ]);
    $sub_url = 'odata/Priority/tabula.ini/efk/B2B_PHCUSTONE?$filter=ACTIVEFLAG eq \'Y\'';
    // print_r($sub_url);die;
    $response = $client->get($sub_url);
    // echo count($response['value']);die;
    return $response;
});

$app->get('/fetch-offer', function (Request $request, Response $response, array $args) {
    $offer_id = $request->getQueryParams('offer_id')['offer_id'];
    // echo $offer_id;die;
    $sql = "SELECT parts.PARTNAME, parts.PARTDES, parts.SUPNAME, parts.DEXT_IMPORTERNAME, parts.VATPRICE, parts.WSPLPRICE, parts.IMGFILENAME, parts.DEXT_LOWSTOCKQTY, discount.DISCOUNT, discount.OFFERQTY, discount.OFFERDES, discount.OFFERID, discount.DEXT_OFFERCODE, stock.TBALANCE FROM `discount` INNER JOIN parts on discount.DEXT_OFFERPARTNAME = parts.PARTNAME INNER JOIN stock ON discount.DEXT_OFFERPARTNAME = stock.PARTNAME WHERE discount.OFFERID = :offerId";

    try {
        // Get DB Object
        $db = new db();
        // Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);
        $stmt->bindValue(':offerId', $offer_id, PDO::PARAM_INT);
        // $stmt->debugDumpParams();
        // die;
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // print_r($result );die;
        return $response->withStatus(200)->withJson($result);
    } catch (PDOException $e) {
        echo '{"error": {"text": ' . $e->getMessage() . '}';
    }


    // print_r($response);die;

    return $response;
});

$app->run();
